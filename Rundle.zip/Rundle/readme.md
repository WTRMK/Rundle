# Rundle

Rundle — это простой и быстрый язык программирования, компилируемый в LLVM IR.

## Сборка

```bash
cargo build
pub fn spawn<F>(task: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::spawn(task);
}

pub async fn await<T>(future: impl std::future::Future<Output = T>) -> T {
    future.await
}
pub fn spawn<F>(task: F)
where
    F: FnOnce() + Send + 'static,
{
    std::thread::spawn(task);
}

pub fn join(handle: std::thread::JoinHandle<()>) {
    handle.join().unwrap();
}
use hip_runtime_sys::*;
use rocblas_sys::*;
use rocfft_sys::*;
use miopen_sys::*;
use rocrand_sys::*;
use rocprim_sys::*;

pub fn init() {
    unsafe { hipInit(0) }.check_err();
}

pub fn malloc(size: usize) -> *mut u8 {
    let mut ptr: *mut core::ffi::c_void = std::ptr::null_mut();
    unsafe { hipMalloc(&mut ptr, size) }.check_err();
    ptr as *mut u8
}

pub fn free(ptr: *mut u8) {
    unsafe { hipFree(ptr as *mut _) }.check_err();
}

pub fn memcpy(dst: *mut u8, src: *const u8, size: usize) {
    unsafe {
        hipMemcpy(
            dst as *mut _,
            src as *const _,
            size,
            hipMemcpyKind::hipMemcpyHostToDevice
        )
    }.check_err();
}

pub fn launch_kernel(name: &str, blocks: usize, threads: usize, args: &[*mut u8]) {
    let kernel = get_kernel(name);
    unsafe {
        hipLaunchKernelGGL(
            kernel,
            blocks as u32,
            threads as u32,
            0,
            0,
            args.as_ptr() as *mut _,
        )
    }.check_err();
}

pub fn rocblas_create_handle() -> rocblas_handle {
    let mut handle: rocblas_handle = std::ptr::null_mut();
    unsafe { rocblas_create_handle(&mut handle) }.check_err();
    handle
}

pub fn rocblas_destroy_handle(handle: rocblas_handle) {
    unsafe { rocblas_destroy_handle(handle) }.check_err();
}

pub fn rocblas_saxpy(handle: rocblas_handle, n: usize, alpha: f32, x: *const f32, y: *mut f32) {
    unsafe {
        rocblas_saxpy(
            handle,
            n as i32,
            &alpha as *const _,
            x as *const _,
            1,
            y as *mut _,
            1
        )
    }.check_err();
}

pub fn rocfft_create_plan(n: usize) -> rocfft_plan {
    let mut plan: rocfft_plan = std::ptr::null_mut();
    unsafe { rocfft_plan_create(&mut plan, n as i32) }.check_err();
    plan
}

pub fn rocfft_execute(plan: rocfft_plan, input: *const f32, output: *mut f32) {
    unsafe {
        rocfft_execute(
            plan,
            input as *const _ as *mut _,
            output as *mut _,
            std::ptr::null_mut()
        )
    }.check_err();
}

pub fn rocfft_destroy_plan(plan: rocfft_plan) {
    unsafe { rocfft_plan_destroy(plan) }.check_err();
}

pub fn rocrand_create_generator() -> rocrand_generator {
    let mut gen: rocrand_generator = std::ptr::null_mut();
    unsafe { rocrand_create_generator(&mut gen, rocrand_rng_type::ROCrand_RNG_PSEUDO_DEFAULT) }.check_err();
    gen
}

pub fn rocrand_generate_uniform(gen: rocrand_generator, data: *mut f32, n: usize) {
    unsafe {
        rocrand_generate_uniform(
            gen,
            data as *mut _,
            n as u64
        )
    }.check_err();
}

pub fn rocrand_destroy_generator(gen: rocrand_generator) {
    unsafe { rocrand_destroy_generator(gen) }.check_err();
}

pub fn rocprim_sort(data: *mut f32, n: usize) {
    unsafe {
        rocprim::sort(
            data as *mut _,
            n as u64,
            std::ptr::null_mut()
        )
    }.check_err();
}

trait RocmResultExt {
    fn check_err(self);
}

impl RocmResultExt for hipError_t {
    fn check_err(self) {
        if self != hipError_t::hipSuccess {
            panic!("ROCm error: {:?}", self);
        }
    }
}

impl RocmResultExt for rocblas_status {
    fn check_err(self) {
        if self != rocblas_status::rocblas_status_success {
            panic!("rocBLAS error: {:?}", self);
        }
    }
}

impl RocmResultExt for rocfft_status {
    fn check_err(self) {
        if self != rocfft_status::rocfft_status_success {
            panic!("rocFFT error: {:?}", self);
        }
    }
}

impl RocmResultExt for rocrand_status {
    fn check_err(self) {
        if self != rocrand_status::rocrand_status_success {
            panic!("rocRAND error: {:?}", self);
        }
    }
}

impl RocmResultExt for rocprim_status {
    fn check_err(self) {
        if self != rocprim_status::rocprim_status_success {
            panic!("rocPRIM error: {:?}", self);
        }
    }
}
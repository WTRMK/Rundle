use cuda_runtime_sys::*;
use cublas_sys::*;
use cufft_sys::*;
use cudnn_sys::*;
use curand_sys::*;
use thrust_sys::*;

pub fn init() {
    unsafe { cuInit(0) }.check_err();
}

pub fn malloc(size: usize) -> *mut u8 {
    let mut ptr: CUdeviceptr = 0;
    unsafe { cuMemAlloc(&mut ptr, size) }.check_err();
    ptr as *mut u8
}

pub fn free(ptr: *mut u8) {
    unsafe { cuMemFree(ptr as CUdeviceptr) }.check_err();
}

pub fn memcpy(dst: *mut u8, src: *const u8, size: usize) {
    unsafe {
        cuMemcpyHtoD(
            dst as CUdeviceptr,
            src as *const _,
            size
        )
    }.check_err();
}

pub fn launch_kernel(name: &str, blocks: usize, threads: usize, args: &[*mut u8]) {
    let kernel = get_kernel(name);
    unsafe {
        cuLaunchKernel(
            kernel,
            blocks as u32,
            1,
            1,
            threads as u32,
            1,
            1,
            0,
            std::ptr::null_mut(),
            args.as_ptr() as *mut _,
            std::ptr::null_mut()
        )
    }.check_err();
}

pub fn cublas_create_handle() -> cublasHandle_t {
    let mut handle: cublasHandle_t = std::ptr::null_mut();
    unsafe { cublasCreate_v2(&mut handle) }.check_err();
    handle
}

pub fn cublas_destroy_handle(handle: cublasHandle_t) {
    unsafe { cublasDestroy_v2(handle) }.check_err();
}

pub fn cublas_saxpy(handle: cublasHandle_t, n: usize, alpha: f32, x: *const f32, y: *mut f32) {
    unsafe {
        cublasSaxpy_v2(
            handle,
            n as i32,
            &alpha as *const _,
            x as *const _,
            1,
            y as *mut _,
            1
        )
    }.check_err();
}

pub fn cufft_create_plan(n: usize) -> cufftHandle {
    let mut plan: cufftHandle = 0;
    unsafe { cufftPlan1d(&mut plan, n as i32, cufftType::CUFFT_R2C, 1) }.check_err();
    plan
}

pub fn cufft_execute(plan: cufftHandle, input: *const f32, output: *mut f32) {
    unsafe {
        cufftExecR2C(
            plan,
            input as *mut _,
            output as *mut _
        )
    }.check_err();
}

pub fn cufft_destroy_plan(plan: cufftHandle) {
    unsafe { cufftDestroy(plan) }.check_err();
}

pub fn curand_create_generator() -> curandGenerator_t {
    let mut gen: curandGenerator_t = std::ptr::null_mut();
    unsafe { curandCreateGenerator(&mut gen, curandRngType::CURAND_RNG_PSEUDO_DEFAULT) }.check_err();
    gen
}

pub fn curand_generate_uniform(gen: curandGenerator_t, data: *mut f32, n: usize) {
    unsafe {
        curandGenerateUniform(
            gen,
            data as *mut _,
            n as u64
        )
    }.check_err();
}

pub fn curand_destroy_generator(gen: curandGenerator_t) {
    unsafe { curandDestroyGenerator(gen) }.check_err();
}

pub fn thrust_sort(data: *mut f32, n: usize) {
    unsafe {
        thrust::sort(
            thrust::device_ptr::new(data as *mut _),
            thrust::device_ptr::new(data as *mut _).add(n)
        )
    }.check_err();
}

trait CudaResultExt {
    fn check_err(self);
}

impl CudaResultExt for CUresult {
    fn check_err(self) {
        if self != CUresult::CUDA_SUCCESS {
            panic!("CUDA error: {:?}", self);
        }
    }
}

impl CudaResultExt for cublasStatus_t {
    fn check_err(self) {
        if self != cublasStatus_t::CUBLAS_STATUS_SUCCESS {
            panic!("cuBLAS error: {:?}", self);
        }
    }
}

impl CudaResultExt for cufftResult {
    fn check_err(self) {
        if self != cufftResult::CUFFT_SUCCESS {
            panic!("cuFFT error: {:?}", self);
        }
    }
}

impl CudaResultExt for curandStatus_t {
    fn check_err(self) {
        if self != curandStatus_t::CURAND_STATUS_SUCCESS {
            panic!("cuRAND error: {:?}", self);
        }
    }
}

impl CudaResultExt for thrust::system::cuda::detail::errc_type {
    fn check_err(self) {
        if self != thrust::system::cuda::detail::errc_type::success {
            panic!("Thrust error: {:?}", self);
        }
    }
}
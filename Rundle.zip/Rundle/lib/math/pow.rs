pub fn pow(x: f64, y: f64) -> f64 {
    x.powf(y)
}
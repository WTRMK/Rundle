use super::lexer::Token;

#[derive(Debug)]
pub enum Expr {
    Number(i64),
    Float(f64),
    StringLiteral(String),
    BinaryOp(Box<Expr>, String, Box<Expr>),
    IfElse(Box<Expr>, Box<Expr>, Box<Expr>),
    FunctionCall(String, Vec<Expr>),
    Ptr(Box<Expr>),
    Alloc(Box<Expr>),
    Free(Box<Expr>),
}

pub fn parse(tokens: Vec<Token>) -> Expr {
    let mut iter = tokens.iter().peekable();
    parse_expr(&mut iter)
}

fn parse_expr<'a>(iter: &mut std::iter::Peekable<std::slice::Iter<'a, Token>>) -> Expr {
    if let Some(token) = iter.next() {
        match token {
            Token::Number(n) => Expr::Number(*n),
            Token::Float(f) => Expr::Float(*f),
            Token::StringLiteral(s) => Expr::StringLiteral(s.clone()),
            Token::Ptr => {
                if let Some(Token::Identifier(ident)) = iter.peek() {
                    iter.next();
                    Expr::Ptr(Box::new(Expr::Identifier(ident.clone())))
                } else {
                    panic!("Expected identifier after 'ptr'");
                }
            }
            Token::Alloc => {
                if let Some(Token::Number(size)) = iter.peek() {
                    iter.next();
                    Expr::Alloc(Box::new(Expr::Number(*size)))
                } else {
                    panic!("Expected size after 'alloc'");
                }
            }
            Token::Free => {
                if let Some(Token::Identifier(ident)) = iter.peek() {
                    iter.next();
                    Expr::Free(Box::new(Expr::Identifier(ident.clone())))
                } else {
                    panic!("Expected identifier after 'free'");
                }
            }
            _ => panic!("Unexpected token"),
        }
    } else {
        panic!("Unexpected end of tokens");
    }
}
pub fn log_error(message: &str) {
    eprintln!("Error: {}", message);
}
use std::path::PathBuf;
use structopt::StructOpt;

#[derive(StructOpt)]
pub struct Cli {
    #[structopt(parse(from_os_str))]
    pub input_file: PathBuf,

    #[structopt(parse(from_os_str))]
    pub output_file: PathBuf,
}

pub fn parse_args() -> Cli {
    Cli::from_args()
}
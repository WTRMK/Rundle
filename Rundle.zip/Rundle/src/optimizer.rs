use super::parser::Expr;

pub fn optimize(ast: Expr) -> Expr {
    match ast {
        Expr::BinaryOp(left, op, right) => {
            if let (Expr::Number(a), Expr::Number(b)) = (*left, *right) {
                match op.as_str() {
                    "+" => Expr::Number(a + b),
                    "-" => Expr::Number(a - b),
                    "*" => Expr::Number(a * b),
                    "/" => Expr::Number(a / b),
                    _ => Expr::BinaryOp(Box::new(Expr::Number(a)), op, Box::new(Expr::Number(b))),
                }
            } else {
                Expr::BinaryOp(left, op, right)
            }
        }
        Expr::Ptr(expr) => Expr::Ptr(Box::new(optimize(*expr))),
        Expr::Alloc(size) => Expr::Alloc(Box::new(optimize(*size))),
        Expr::Free(ptr) => Expr::Free(Box::new(optimize(*ptr))),
        _ => ast,
    }
}
use super::parser::Expr;

pub fn generate(ast: Expr) -> String {
    match ast {
        Expr::Number(n) => format!("ret i32 {}", n),
        Expr::Float(f) => format!("ret double {}", f),
        Expr::BinaryOp(left, op, right) => {
            let left_code = generate(*left);
            let right_code = generate(*right);
            format!("{} {} {}", left_code, op, right_code)
        }
        Expr::Ptr(expr) => {
            let expr_code = generate(*expr);
            format!("ptr {}", expr_code)
        }
        Expr::Alloc(size) => {
            let size_code = generate(*size);
            format!("alloc {}", size_code)
        }
        Expr::Free(ptr) => {
            let ptr_code = generate(*ptr);
            format!("free {}", ptr_code)
        }
        _ => panic!("Unsupported expression"),
    }
}
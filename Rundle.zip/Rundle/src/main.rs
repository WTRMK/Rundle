mod lexer;
mod parser;
mod codegen;
mod optimizer;
mod cli;
mod utils;

use cli::parse_args;
use std::fs;

fn main() {
    let args = parse_args();
    let source_code = fs::read_to_string(&args.input_file).expect("Failed to read file");

    // Лексический анализ
    let tokens = lexer::tokenize(&source_code);

    // Синтаксический анализ
    let ast = parser::parse(tokens);

    // Оптимизация AST
    let optimized_ast = optimizer::optimize(ast);

    // Генерация кода
    let llvm_ir = codegen::generate(optimized_ast);

    // Запись результата
    fs::write(&args.output_file, llvm_ir).expect("Failed to write file");
}
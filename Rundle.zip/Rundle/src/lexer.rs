#[derive(Debug)]
pub enum Token {
    Identifier(String),
    Number(i64),
    Float(f64),
    StringLiteral(String),
    Keyword(String),
    Operator(String),
    Ptr,
    Alloc,
    Free, 
    EOF,
}

pub fn tokenize(source: &str) -> Vec<Token> {
    let mut tokens = Vec::new();
    let mut chars = source.chars().peekable();

    while let Some(c) = chars.next() {
        match c {
            'a'..='z' | 'A'..='Z' => {
                let mut identifier = String::new();
                identifier.push(c);
                while let Some(&next_char) = chars.peek() {
                    if next_char.is_alphanumeric() {
                        identifier.push(chars.next().unwrap());
                    } else {
                        break;
                    }
                }
                match identifier.as_str() {
                    "ptr" => tokens.push(Token::Ptr),
                    "alloc" => tokens.push(Token::Alloc),
                    "free" => tokens.push(Token::Free),
                    _ => tokens.push(Token::Identifier(identifier)),
                }
            }
            '0'..='9' => {
                let mut number = String::new();
                number.push(c);
                while let Some(&next_char) = chars.peek() {
                    if next_char.is_digit(10) || next_char == '.' {
                        number.push(chars.next().unwrap());
                    } else {
                        break;
                    }
                }
                if number.contains('.') {
                    tokens.push(Token::Float(number.parse().unwrap()));
                } else {
                    tokens.push(Token::Number(number.parse().unwrap()));
                }
            }
            '"' => {
                let mut string_literal = String::new();
                while let Some(&next_char) = chars.peek() {
                    if next_char != '"' {
                        string_literal.push(chars.next().unwrap());
                    } else {
                        chars.next();
                        break;
                    }
                }
                tokens.push(Token::StringLiteral(string_literal));
            }
            _ => {
                if !c.is_whitespace() {
                    tokens.push(Token::Operator(c.to_string()));
                }
            }
        }
    }

    tokens.push(Token::EOF);
    tokens
}
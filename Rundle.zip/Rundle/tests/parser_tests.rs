use super::parser::parse;
use super::lexer::tokenize;

#[test]
fn test_parse() {
    let source_code = "42";
    let tokens = tokenize(source_code);
    let ast = parse(tokens);
    assert!(matches!(ast, super::parser::Expr::Number(42)));
}
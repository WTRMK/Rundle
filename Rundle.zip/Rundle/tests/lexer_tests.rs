use super::lexer::tokenize;

#[test]
fn test_tokenize() {
    let source_code = "int main { return 0; }";
    let tokens = tokenize(source_code);
    assert_eq!(tokens.len(), 7);
}
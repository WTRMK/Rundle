use super::codegen::generate;
use super::parser::Expr;

#[test]
fn test_generate() {
    let ast = Expr::Number(42);
    let code = generate(ast);
    assert_eq!(code, "ret i32 42");
}